#! /usr/bin/env python

if __name__ == '__main__':
	number1 = input("Voer getal 1 in: ")
	number2 = input("Voer getal 2 in: ")
print "Het resultaat van de optelling van ", number1, " en ", number2, " is ", (number1 + number2)


